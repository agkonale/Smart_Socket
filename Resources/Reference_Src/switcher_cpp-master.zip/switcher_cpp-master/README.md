# Switcher – A WiFi Open Source Power Switch and Socket

[Detailed Description](http://hristoborisov.com/index.php/projects/switcher-a-wifi-open-source-power-switch/)
